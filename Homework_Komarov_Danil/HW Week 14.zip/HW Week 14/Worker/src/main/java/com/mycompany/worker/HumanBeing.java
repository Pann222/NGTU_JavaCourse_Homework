/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.worker;

/**
 *
 * @author Dan20
 */
public abstract class HumanBeing {
    int age;
    float height;
    float weight;
    
    abstract float bodyMassIndex();
    abstract void eat();

}
